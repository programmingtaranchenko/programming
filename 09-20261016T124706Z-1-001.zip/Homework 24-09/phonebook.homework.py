contacts = {}

while True:
    command = input("Введіть команду (add, delete, search, show, exit): ").strip().lower()

    if command == "add":
        name = input("Введіть ім'я: ")
        number = input("Введіть номер: ")
        contacts.update({name: number})

    elif command == "delete":
        name = input("Введіть ім'я: ")
        if name in contacts:
            del contacts[name]
            print("Контакт видалено")
        else:
            print("Not found")

    elif command == "search":
        name = input("Введіть ім'я: ")
        if name in contacts:
            print(contacts[name])
        else:
            print("Not found")

    elif command == "show":
        if not contacts:
            print("Телефонна книга поки порожня.")
        else:
            for name, phone in contacts.items():
                print(f"{name}: {phone}")

    elif command == "exit":
        break

    else:
        print("Невідома команда")