def calculate_salary(hours, hourly_rate):
    total_salary = hours * hourly_rate
    return total_salary
