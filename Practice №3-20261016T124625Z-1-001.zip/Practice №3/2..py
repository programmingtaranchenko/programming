def create_user(username, role="user", status="active"):
    return f"Користувач: {username}, Роль: {role}, Статус: {status}"
print(create_user("Микола"))
print(create_user("Валентина", "admin"))