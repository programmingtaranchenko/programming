
raw_data = input("Введіть вимірювання через пробіл: ").split()
numbers = [float(item) for item in raw_data]
m = len(numbers)
mean_val = sum(numbers) / m
sq_errors = []
for x in numbers:
    sq_errors.append((x - mean_val) ** 2)

var_val = sum(sq_errors) / (m - 1)
std_val = var_val ** 0.5
print("Середнє арифметичне:", mean_val)
print("Дисперсія:", var_val)
print("Стандартне відхилення:", std_val)