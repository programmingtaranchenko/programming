x = float(input("Введіть значення x: "))
if x > -5 and x < 5:
    result = 2 * x**2 + 3 * x - 1
else:
    result = 0

print("f(x) =", result)