pi_val = 2.0

for step in range(1, 10001):
    term = (4 * step**2) / (4 * step**2 - 1)
    pi_val *= term

    if step % 100 == 0:
        print(step, pi_val)