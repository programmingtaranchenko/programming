# Зчитуємо текст та переводимо в нижній регістр
from typing import Any

input_text = input("Введіть текст: ").lower()

# Створюємо словник за підказкою
freq_dict: dict[Any, Any] = {}

# Наповнюємо словник підрахованими літерами
for symbol in input_text:
    if symbol.isalpha() and symbol not in freq_dict:
        freq_dict[symbol] = input_text.count(symbol)

# Перевіряємо, чи знайшли хоча б одну літеру
if freq_dict:
    # Знаходимо ключ з максимальним значенням
    best_letter = max(freq_dict, key=freq_dict.get)
    print("Найчастіша літера:", best_letter.upper())
else:
    print("У введеному тексті немає літер!")