a = float(input("Введіть катет a: "))
b = float(input("Введіть катет b: "))

c = (a**2 + b**2)**0.5
S = (a * b) / 2
P = a + b + c

print("Гіпотенуза:", c)
print("Площа:", S)
print("Периметр:", P)