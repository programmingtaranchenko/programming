rows_count = int(input("Введіть n (кількість рядків): "))
cols_count = int(input("Введіть k (кількість стовпців): "))

grid = []
print("Введіть рядки матриці:")
for _ in range(rows_count):
    row_data = list(map(int, input().split()))
    grid.append(row_data)
rows_sums = []
for row in grid:
    rows_sums.append(sum(row))
cols_sums = []
for col in range(cols_count):
    current_sum = 0
    for row in range(rows_count):
        current_sum += grid[row][col]
    cols_sums.append(current_sum)
print("Суми рядків:", rows_sums)
print("Суми стовпців:", cols_sums)