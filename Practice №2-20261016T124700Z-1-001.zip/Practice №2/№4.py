n = 1
while not (1.02**n > 1000 * n**2):
    n = n + 1

print("Найменше значення n =", n)