pwd = input("Введіть пароль: ")
has_low = False
has_up = False
has_num = False

for char in pwd:
    if char.islower():
        has_low = True
    if char.isupper():
        has_up = True
    if char.isdigit():
        has_num = True

if has_low and has_up and has_num:
    print("Password is secure.")
else:
    print("Password is unsafe!")