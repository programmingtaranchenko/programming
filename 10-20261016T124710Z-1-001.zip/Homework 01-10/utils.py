# utils.py
import math
def calculate_trip_cost(distance, fuel_consumption, fuel_price):
    liters_needed = (distance / 100) * fuel_consumption
    total_cost = liters_needed * fuel_price
    return math.ceil(total_cost)
# Розрахунок вартості поїздки авто від м.Нивки до м.Університет:
distance = 8          # км
fuel_consumption = 8  # літрів на 100 км
fuel_price = 95       # грн за літр

cost = calculate_trip_cost(distance, fuel_consumption, fuel_price)
print(f"Вартість поїздки: {cost} грн")