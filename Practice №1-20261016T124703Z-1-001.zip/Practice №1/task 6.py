a = int(input("Уведіть число N: "))
fact = 1

for step in range(1, a + 1):
    fact *= step

print(f"Факторіал числа {a} дорівнює: {fact}")