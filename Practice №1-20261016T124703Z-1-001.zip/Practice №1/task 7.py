for current_num in range(1, 51):
    if current_num == 20:
        break
    if current_num % 3 == 0:
        continue
    print(f"Число: {current_num}")