speed_list = [36, 72, 90, 108]
for pos in range(len(speed_list)):
    speed_list[pos] = speed_list[pos] / 3.6
print(speed_list)