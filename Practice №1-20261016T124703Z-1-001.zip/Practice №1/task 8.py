numbers_vector = [10, 20, 30, 40, 50, 60, 70]

print(numbers_vector[:3])
print(numbers_vector[2:])
print(numbers_vector[::-1])