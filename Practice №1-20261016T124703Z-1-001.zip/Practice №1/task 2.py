name = input("Уведіть ім'я: ")
surname = input("Уведіть прізвище: ")

formatted_name = name.title()
formatted_surname = surname.upper()

print(f"Оформлений запис: {formatted_name} {formatted_surname}")