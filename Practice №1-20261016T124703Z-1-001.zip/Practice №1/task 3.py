x = int(input("Координата X: "))
y = int(input("Координата Y: "))
if x > 0 and y > 0:
    print(f"Точка ({x}, {y}) належить I чверті")
elif x < 0 and y > 0:
    print(f"Точка ({x}, {y}) належить II чверті")
elif x < 0 and y < 0:
    print(f"Точка ({x}, {y}) належить III чверті")
elif x > 0 and y < 0:
    print(f"Точка ({x}, {y}) належить IV чверті")
else:
    print(f"Точка ({x}, {y}) розміщена на осях")