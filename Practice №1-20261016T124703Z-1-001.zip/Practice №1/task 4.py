
a = float(input("Введіть перше число: "))
b = float(input("Введіть друге число: "))
op = input("Введіть оператор (+, -, *, /): ")

if op == "+":
    print(a + b)
elif op == "-":
    print(a - b)
elif op == "*":
    print(a * b)
elif op == "/":
    if b != 0:
        print(a / b)
    else:
        print("Помилка: ділення на нуль неможливе!")
else:
    print("Помилка: введено невідомий оператор!")