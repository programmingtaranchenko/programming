grades = [8, 11, 7, 10]
grades.remove(7)
grades.append(12)
grades.sort(reverse=True)

print(grades)