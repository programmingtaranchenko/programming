balance = 1000
year_count = 0

while balance <= 2000:
    balance *= 1.10
    year_count += 1

print(f"Необхідна кількість років: {year_count}")